import React from 'react';
import { FaCheck } from 'react-icons/fa';

const FeatureItem = ({ children }) => {
  return (
    <div className="offer-item">
      <div className="offer-icon">
        <FaCheck />
      </div>
      <div>{children}</div>
    </div>
  );
};

export default FeatureItem;
