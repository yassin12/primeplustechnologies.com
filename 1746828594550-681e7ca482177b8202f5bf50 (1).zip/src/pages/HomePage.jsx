import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import ServiceCard from '../components/ServiceCard';
import FeatureItem from '../components/FeatureItem';
import { 
  FaServer, 
  FaShieldAlt, 
  FaPhone, 
  FaNetworkWired, 
  FaPrint, 
  FaVideo,
  FaSolarPanel,
  FaLaptop,
  FaUserTie,
  FaTools,
  FaCog,
  FaTachometerAlt
} from 'react-icons/fa';

const HomePage = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="hero d-flex align-items-center">
        <Container>
          <Row>
            <Col lg={8}>
              <h1>Technology Without Limits</h1>
              <p>PRIME PLUS TECHNOLOGIES is a leading provider of integrated technology solutions, empowering businesses to thrive in the digital age.</p>
              <Link to="/contact">
                <Button variant="secondary" size="lg" className="me-3">Contact Us</Button>
              </Link>
              <Link to="/about">
                <Button variant="outline-light" size="lg">Learn More</Button>
              </Link>
            </Col>
          </Row>
        </Container>
      </section>

      {/* About Section */}
      <section className="section">
        <Container>
          <Row className="align-items-center">
            <Col lg={6} className="mb-5 mb-lg-0">
              <h2 className="section-title">About PRIME PLUS TECHNOLOGIES</h2>
              <p>We specialize in delivering cutting-edge IT infrastructure, smart office solutions, and advanced security systems all designed to streamline operations, enhance productivity, and future-proof your organization.</p>
              <p>At PRIME PLUS TECHNOLOGIES, we bring deep technical knowledge and proven industry experience to deliver comprehensive ICT solutions. Our team of certified professionals specializes in designing, implementing, and managing end-to-end technology infrastructure that keeps businesses connected, secure, and productive.</p>
              <Link to="/about" className="btn btn-primary mt-3">Discover Our Expertise</Link>
            </Col>
            <Col lg={6}>
              <img 
                src="https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=900&q=80" 
                alt="IT Professionals" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
        </Container>
      </section>

      {/* Services Section */}
      <section className="section bg-light-subtle">
        <Container>
          <Row className="text-center mb-5">
            <Col>
              <h2 className="section-title text-center">Our Services</h2>
              <p className="section-subtitle">Comprehensive technology solutions for your business needs</p>
            </Col>
          </Row>
          <Row>
            <Col lg={4} md={6} className="mb-4">
              <ServiceCard 
                title="Solar Installation"
                description="Sustainable energy solutions for businesses with expert installation and maintenance services."
                icon={<FaSolarPanel />}
                imgSrc="https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
                link="/solar"
              />
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <ServiceCard 
                title="IT Infrastructure"
                description="Robust IT infrastructure solutions designed to ensure business continuity and enhance productivity."
                icon={<FaServer />}
                imgSrc="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
                link="/ict-solutions"
              />
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <ServiceCard 
                title="Cybersecurity"
                description="Comprehensive security services to protect your critical assets and sensitive data from threats."
                icon={<FaShieldAlt />}
                imgSrc="https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
                link="/ict-solutions"
              />
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <ServiceCard 
                title="Unified Communications"
                description="Integrate voice, video, and collaboration tools into seamless communication ecosystems."
                icon={<FaPhone />}
                imgSrc="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
                link="/ict-solutions"
              />
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <ServiceCard 
                title="Structured Cabling"
                description="Enterprise-grade cabling systems designed for performance and scalability."
                icon={<FaNetworkWired />}
                imgSrc="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
                link="/ict-solutions"
              />
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <ServiceCard 
                title="ICT Equipment Supply"
                description="Genuine hardware with warranty support from authorized distributors."
                icon={<FaLaptop />}
                imgSrc="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
                link="/equipment"
              />
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <ServiceCard 
                title="Printer Services"
                description="Professional printer solutions with certified technicians for peak performance."
                icon={<FaPrint />}
                imgSrc="https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
                link="/printer-services"
              />
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <ServiceCard 
                title="CCTV & Access Control"
                description="Intelligent security systems providing 360° protection with smart surveillance."
                icon={<FaVideo />}
                imgSrc="https://images.unsplash.com/photo-1610641818989-c2051b5e2cfd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
                link="/cctv"
              />
            </Col>
          </Row>
        </Container>
      </section>

      {/* Why Choose Us */}
      <section className="section why-us">
        <Container>
          <Row className="text-center mb-5">
            <Col>
              <h2 className="section-title text-center">Why Choose Us</h2>
              <p className="section-subtitle">Partner with us for innovative, reliable technology solutions</p>
            </Col>
          </Row>
          <Row>
            <Col lg={4} md={6} className="mb-4">
              <div className="reason-item text-center">
                <div className="reason-icon">
                  <FaUserTie />
                </div>
                <h4>Industry Experience</h4>
                <p>Years of experience and deep understanding of the industries we serve, bringing specialized knowledge to every project.</p>
              </div>
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <div className="reason-item text-center">
                <div className="reason-icon">
                  <FaTools />
                </div>
                <h4>Skilled Professionals</h4>
                <p>Our team comprises experts in their respective fields, dedicated to delivering top-notch technology services.</p>
              </div>
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <div className="reason-item text-center">
                <div className="reason-icon">
                  <FaCog />
                </div>
                <h4>Innovation</h4>
                <p>We stay at the forefront of industry trends and technologies, offering modern solutions for evolving business needs.</p>
              </div>
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <div className="reason-item text-center">
                <div className="reason-icon">
                  <FaTachometerAlt />
                </div>
                <h4>Quality Assurance</h4>
                <p>Quality is at the heart of everything we do, ensuring our services meet the highest standards of excellence.</p>
              </div>
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <div className="reason-item text-center">
                <div className="reason-icon">
                  <FaShieldAlt />
                </div>
                <h4>Regulatory Compliance</h4>
                <p>We stay up-to-date with relevant regulations, ensuring our services are in full compliance with industry standards.</p>
              </div>
            </Col>
            <Col lg={4} md={6} className="mb-4">
              <div className="reason-item text-center">
                <div className="reason-icon">
                  <FaLaptop />
                </div>
                <h4>Customization</h4>
                <p>We understand that every client is unique, tailoring our services to meet individual requirements with precision.</p>
              </div>
            </Col>
          </Row>
          <Row className="mt-4 text-center">
            <Col>
              <Link to="/contact">
                <Button variant="light" size="lg">Contact Us Today</Button>
              </Link>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Call to Action */}
      <section className="section">
        <Container>
          <Row className="text-center">
            <Col lg={8} className="mx-auto">
              <h2 className="section-title text-center">Ready to Transform Your Business?</h2>
              <p className="mb-4">Connect with our team of experts today to discuss how our technology solutions can empower your business growth.</p>
              <Link to="/contact">
                <Button variant="primary" size="lg">Get In Touch</Button>
              </Link>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default HomePage;
