import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaPhone, FaEnvelope, FaMapMarkerAlt, FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer>
      <div className="footer">
        <Container>
          <Row>
            <Col lg={4} md={6} className="mb-4 mb-md-0">
              <h5 className="mb-4">PRIME PLUS TECHNOLOGIES</h5>
              <p>Empowering businesses with transformative technology solutions that drive efficiency, security, and growth.</p>
              <div className="social-icons mt-4">
                <a href="#" aria-label="Facebook"><FaFacebookF /></a>
                <a href="#" aria-label="Twitter"><FaTwitter /></a>
                <a href="#" aria-label="LinkedIn"><FaLinkedinIn /></a>
                <a href="#" aria-label="Instagram"><FaInstagram /></a>
              </div>
            </Col>
            
            <Col lg={2} md={6} className="mb-4 mb-md-0">
              <h5>Quick Links</h5>
              <ul className="list-unstyled">
                <li><Link to="/">Home</Link></li>
                <li><Link to="/about">About Us</Link></li>
                <li><Link to="/solar">Solar Installation</Link></li>
                <li><Link to="/ict-solutions">ICT Solutions</Link></li>
                <li><Link to="/contact">Contact Us</Link></li>
              </ul>
            </Col>
            
            <Col lg={2} md={6} className="mb-4 mb-md-0">
              <h5>Our Services</h5>
              <ul className="list-unstyled">
                <li><Link to="/ict-solutions">IT Infrastructure</Link></li>
                <li><Link to="/ict-solutions">Cybersecurity</Link></li>
                <li><Link to="/ict-solutions">Structured Cabling</Link></li>
                <li><Link to="/equipment">ICT Equipment</Link></li>
                <li><Link to="/cctv">CCTV & Access Control</Link></li>
              </ul>
            </Col>
            
            <Col lg={4} md={6}>
              <h5>Contact Information</h5>
              <div className="footer-contact">
                <div className="contact-icon-small">
                  <FaPhone />
                </div>
                <div>
                  <p className="mb-0">+252-617527771 / +252-610855016</p>
                </div>
              </div>
              <div className="footer-contact">
                <div className="contact-icon-small">
                  <FaEnvelope />
                </div>
                <div>
                  <p className="mb-0">info@primeplustechnologies.com</p>
                </div>
              </div>
              <div className="footer-contact">
                <div className="contact-icon-small">
                  <FaMapMarkerAlt />
                </div>
                <div>
                  <p className="mb-0">Vinta une October Rd, Waaberi District</p>
                  <p className="mb-0">Mogadishu, Somalia</p>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
      <div className="copyright-bar">
        <Container>
          <p className="mb-0">© 2025 Prime Plus Technologies. All rights reserved.</p>
        </Container>
      </div>
    </footer>
  );
};

export default Footer;
