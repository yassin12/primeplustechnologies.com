import React from 'react';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import PageHeader from '../components/PageHeader';
import FeatureItem from '../components/FeatureItem';
import { FaServer, FaShieldAlt, FaPhone, FaNetworkWired } from 'react-icons/fa';

const ICTSolutionsPage = () => {
  return (
    <>
      <PageHeader 
        title="ICT Solutions" 
        breadcrumbs={[{ text: "ICT Solutions" }]} 
      />
      
      <section className="section">
        <Container>
          <Row className="mb-5">
            <Col lg={12} className="text-center">
              <h2 className="section-title text-center">Comprehensive ICT Solutions</h2>
              <p className="section-subtitle">End-to-end technology infrastructure solutions for modern businesses</p>
            </Col>
          </Row>
          
          {/* IT Infrastructure & Managed Services */}
          <Row className="align-items-center mb-5">
            <Col lg={6} className="mb-4 mb-lg-0">
              <div className="d-flex align-items-center mb-4">
                <FaServer className="text-primary me-3" style={{ fontSize: "2.5rem" }} />
                <h3 className="mb-0">IT Infrastructure & Managed Services</h3>
              </div>
              <p>In today's digital landscape, a robust IT infrastructure forms the backbone of every successful organization. Our enterprise-grade solutions are designed to ensure business continuity, enhance productivity, and support scalable growth.</p>
              <p>We take a holistic approach to IT management, from physical network architecture to cloud integration, providing seamless technology ecosystems tailored to your operational requirements. Our certified network engineers implement best-practice solutions that prioritize security, reliability, and ease of management.</p>
              <h4 className="h5 mt-4 mb-3">What We Offer:</h4>
              <FeatureItem>End-to-end network design and implementation (wired/wireless)</FeatureItem>
              <FeatureItem>Server virtualization and cloud migration strategies</FeatureItem>
              <FeatureItem>Enterprise storage solutions (SAN/NAS) and data center services</FeatureItem>
              <FeatureItem>24/7 network monitoring and helpdesk support</FeatureItem>
              <FeatureItem>Technology refresh planning and lifecycle management</FeatureItem>
            </Col>
            <Col lg={6}>
              <img 
                src="https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="IT Infrastructure" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
          
          {/* Cybersecurity */}
          <Row className="align-items-center mb-5">
            <Col lg={6} className="order-lg-2 mb-4 mb-lg-0">
              <div className="d-flex align-items-center mb-4">
                <FaShieldAlt className="text-primary me-3" style={{ fontSize: "2.5rem" }} />
                <h3 className="mb-0">Cybersecurity</h3>
              </div>
              <p>With cyber threats growing in sophistication, our comprehensive security services protect your critical assets and sensitive data. We employ a multi-layered defense strategy that combines advanced technology with continuous monitoring and employee awareness training.</p>
              <p>Our security experts conduct thorough risk assessments to identify vulnerabilities before they can be exploited, implementing robust countermeasures that align with international security standards and compliance requirements.</p>
              <h4 className="h5 mt-4 mb-3">What We Offer:</h4>
              <FeatureItem>Enterprise-grade firewall deployment and configuration</FeatureItem>
              <FeatureItem>Endpoint protection and mobile device management</FeatureItem>
              <FeatureItem>Security information and event monitoring (SIEM)</FeatureItem>
              <FeatureItem>Phishing simulation and security awareness training</FeatureItem>
              <FeatureItem>Incident response planning and digital forensics</FeatureItem>
            </Col>
            <Col lg={6} className="order-lg-1">
              <img 
                src="https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Cybersecurity" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
          
          {/* Unified Communications */}
          <Row className="align-items-center mb-5">
            <Col lg={6} className="mb-4 mb-lg-0">
              <div className="d-flex align-items-center mb-4">
                <FaPhone className="text-primary me-3" style={{ fontSize: "2.5rem" }} />
                <h3 className="mb-0">Unified Communications</h3>
              </div>
              <p>We integrate voice, video, and collaboration tools into seamless communication ecosystems that keep your teams connected from anywhere. Our unified communications solutions enhance productivity, streamline workflows, and enable efficient remote collaboration.</p>
              <p>Whether you need a simple VoIP phone system or a comprehensive enterprise communications platform, our team designs, implements, and supports solutions that evolve with your business needs.</p>
              <h4 className="h5 mt-4 mb-3">What We Offer:</h4>
              <FeatureItem>VoIP phone system deployment</FeatureItem>
              <FeatureItem>Microsoft Teams/Zoom room setups</FeatureItem>
              <FeatureItem>Video conferencing hardware solutions</FeatureItem>
              <FeatureItem>Call center & CRM integrations</FeatureItem>
              <FeatureItem>24/7 system monitoring & support</FeatureItem>
            </Col>
            <Col lg={6}>
              <img 
                src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Unified Communications" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
          
          {/* Structured Cabling */}
          <Row className="align-items-center">
            <Col lg={6} className="order-lg-2 mb-4 mb-lg-0">
              <div className="d-flex align-items-center mb-4">
                <FaNetworkWired className="text-primary me-3" style={{ fontSize: "2.5rem" }} />
                <h3 className="mb-0">Structured Cabling</h3>
              </div>
              <p>We build reliable network backbones with enterprise-grade cabling systems designed for performance and scalability. Our certified engineers deliver clean, organized infrastructure that supports your current and future bandwidth needs.</p>
              <p>From small office setups to complex data center installations, our structured cabling solutions ensure optimal network performance with minimal downtime and maximum reliability.</p>
              <h4 className="h5 mt-4 mb-3">What We Offer:</h4>
              <FeatureItem>Cat6/Cat6a/Fiber optic cable installation</FeatureItem>
              <FeatureItem>Server room & data center cabling</FeatureItem>
              <FeatureItem>Cable management & labeling systems</FeatureItem>
              <FeatureItem>Comprehensive testing & certification</FeatureItem>
              <FeatureItem>Network infrastructure documentation</FeatureItem>
            </Col>
            <Col lg={6} className="order-lg-1">
              <img 
                src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Structured Cabling" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
        </Container>
      </section>
      
      {/* CTA Section */}
      <section className="section bg-light-subtle">
        <Container>
          <Row className="text-center">
            <Col lg={8} className="mx-auto">
              <h2 className="section-title text-center">Need Custom ICT Solutions?</h2>
              <p className="mb-4">Our experts will analyze your business requirements and design a tailored technology solution that drives efficiency and growth.</p>
              <Link to="/contact">
                <Button variant="primary" size="lg">Request a Consultation</Button>
              </Link>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default ICTSolutionsPage;
