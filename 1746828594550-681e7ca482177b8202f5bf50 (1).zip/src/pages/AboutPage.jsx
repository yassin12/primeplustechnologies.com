import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import PageHeader from '../components/PageHeader';
import { FaUserTie, FaTools, FaLaptop, FaShieldAlt, FaCog, FaTachometerAlt } from 'react-icons/fa';

const AboutPage = () => {
  return (
    <>
      <PageHeader 
        title="About Us" 
        breadcrumbs={[{ text: "About Us" }]} 
      />
      
      <section className="section">
        <Container>
          <Row className="mb-5">
            <Col lg={6} className="mb-4 mb-lg-0">
              <h2 className="section-title">Our Company</h2>
              <p>PRIME PLUS TECHNOLOGIES is a leading provider of integrated technology solutions, empowering businesses to thrive in the digital age. We specialize in delivering cutting-edge IT infrastructure, smart office solutions, and advanced security systems all designed to streamline operations, enhance productivity, and future-proof your organization.</p>
              <p>At PRIME PLUS TECHNOLOGIES, we bring deep technical knowledge and proven industry experience to deliver comprehensive ICT solutions. Our team of certified professionals specializes in designing, implementing, and managing end-to-end technology infrastructure that keeps businesses connected, secure, and productive.</p>
            </Col>
            <Col lg={6}>
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Our Team" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
          
          <Row className="mb-5">
            <Col lg={12}>
              <h2 className="section-title">Our Mission</h2>
              <p>To empower businesses with transformative technology solutions that drive efficiency, security, and growth. We deliver cutting-edge ICT infrastructure, smart office systems, and advanced security integrations—all tailored to help organizations thrive in a digital-first world.</p>
            </Col>
          </Row>
          
          <Row>
            <Col lg={12}>
              <h2 className="section-title mb-5">Our Expertise</h2>
            </Col>
          </Row>
          
          <Row>
            <Col lg={4} md={6} className="mb-4">
              <div className="feature-box">
                <div className="feature-icon">
                  <FaUserTie />
                </div>
                <h3>Industry Experience</h3>
                <p>With years of experience, we have a deep understanding of the industries we serve. In everything we offer, we bring industry-specific knowledge to every project.</p>
              </div>
            </Col>
            
            <Col lg={4} md={6} className="mb-4">
              <div className="feature-box">
                <div className="feature-icon">
                  <FaTools />
                </div>
                <h3>Skilled Professionals</h3>
                <p>Our team comprises skilled individuals who are experts in their respective fields. From logistics experts to interior designers, our professionals are dedicated to delivering top-notch services.</p>
              </div>
            </Col>
            
            <Col lg={4} md={6} className="mb-4">
              <div className="feature-box">
                <div className="feature-icon">
                  <FaCog />
                </div>
                <h3>Innovation</h3>
                <p>We stay at the forefront of industry trends and technologies. Our commitment to innovation allows us to offer modern solutions that meet the evolving needs of our clients.</p>
              </div>
            </Col>
            
            <Col lg={4} md={6} className="mb-4">
              <div className="feature-box">
                <div className="feature-icon">
                  <FaLaptop />
                </div>
                <h3>Customisation</h3>
                <p>We understand that every client and project is unique. Our ability to tailor our services to meet individual requirements is a testament to our expertise in providing customized solutions.</p>
              </div>
            </Col>
            
            <Col lg={4} md={6} className="mb-4">
              <div className="feature-box">
                <div className="feature-icon">
                  <FaShieldAlt />
                </div>
                <h3>Regulatory Compliance</h3>
                <p>We stay up-to-date with relevant regulations and standards. This ensures that our services are not only efficient and cost-effective but also in full compliance with industry requirements.</p>
              </div>
            </Col>
            
            <Col lg={4} md={6} className="mb-4">
              <div className="feature-box">
                <div className="feature-icon">
                  <FaTachometerAlt />
                </div>
                <h3>Quality Assurance</h3>
                <p>Quality is at the heart of everything we do. Our commitment to excellence means that the services we provide meet the highest standards, reflecting the professionalism and integrity of your business.</p>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default AboutPage;
