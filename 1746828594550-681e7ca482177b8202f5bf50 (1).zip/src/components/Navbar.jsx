import React, { useState, useEffect } from 'react';
import { Container, Nav, Navbar as BootstrapNavbar } from 'react-bootstrap';
import { Link, NavLink } from 'react-router-dom';

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <BootstrapNavbar 
      expand="lg" 
      className={`${scrolled ? 'py-2' : 'py-3'} fixed-top bg-white`}
      collapseOnSelect
    >
      <Container>
        <BootstrapNavbar.Brand as={Link} to="/">
          <span className="fw-bold">PRIME PLUS</span> <span className="text-secondary">TECHNOLOGIES</span>
        </BootstrapNavbar.Brand>
        <BootstrapNavbar.Toggle aria-controls="basic-navbar-nav" />
        <BootstrapNavbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link as={NavLink} to="/" end>
              Home
            </Nav.Link>
            <Nav.Link as={NavLink} to="/about">
              About Us
            </Nav.Link>
            <Nav.Link as={NavLink} to="/solar">
              Solar Installation
            </Nav.Link>
            <Nav.Link as={NavLink} to="/ict-solutions">
              ICT Solutions
            </Nav.Link>
            <Nav.Link as={NavLink} to="/equipment">
              Equipment Supply
            </Nav.Link>
            <Nav.Link as={NavLink} to="/printer-services">
              Printer Services
            </Nav.Link>
            <Nav.Link as={NavLink} to="/cctv">
              CCTV & Access
            </Nav.Link>
            <Nav.Link as={NavLink} to="/contact">
              Contact
            </Nav.Link>
          </Nav>
        </BootstrapNavbar.Collapse>
      </Container>
    </BootstrapNavbar>
  );
};

export default Navbar;
