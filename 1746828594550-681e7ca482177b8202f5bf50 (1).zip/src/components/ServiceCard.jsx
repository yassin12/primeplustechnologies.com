import React from 'react';
import { Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const ServiceCard = ({ title, description, icon, imgSrc, link }) => {
  return (
    <Card className="service-card h-100">
      {imgSrc && (
        <Card.Img variant="top" src={imgSrc} alt={title} />
      )}
      <Card.Body className="d-flex flex-column">
        {icon && <div className="service-icon mb-3">{icon}</div>}
        <Card.Title>{title}</Card.Title>
        <Card.Text>{description}</Card.Text>
        <div className="mt-auto">
          <Link to={link} className="btn btn-primary mt-3">Learn More</Link>
        </div>
      </Card.Body>
    </Card>
  );
};

export default ServiceCard;
