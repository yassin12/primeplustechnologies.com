import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import PageHeader from '../components/PageHeader';
import FeatureItem from '../components/FeatureItem';
import { FaSolarPanel, FaLeaf, FaSun, FaChartLine } from 'react-icons/fa';

const SolarPage = () => {
  return (
    <>
      <PageHeader 
        title="Solar Installation" 
        breadcrumbs={[{ text: "Solar Installation" }]} 
      />
      
      <section className="section">
        <Container>
          <Row className="align-items-center mb-5">
            <Col lg={6} className="mb-4 mb-lg-0">
              <h2 className="section-title">Sustainable Energy Solutions</h2>
              <p>At PRIME PLUS TECHNOLOGIES, we offer comprehensive solar energy solutions designed to reduce your energy costs while contributing to a greener future. Our expert team provides end-to-end services from assessment and design to installation and maintenance.</p>
              <p>With our solar installation services, businesses can significantly reduce electricity costs, decrease carbon footprint, and benefit from reliable power even during grid outages.</p>
              <div className="mt-4">
                <Link to="/contact">
                  <Button variant="primary">Request a Consultation</Button>
                </Link>
              </div>
            </Col>
            <Col lg={6}>
              <img 
                src="https://images.unsplash.com/photo-1566093097221-ac2335b08e89?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Solar Panels" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
          
          <Row className="mb-5">
            <Col>
              <h3 className="h2 mb-4">Our Solar Installation Services</h3>
            </Col>
          </Row>
          
          <Row className="mb-5">
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaSolarPanel />
                </div>
                <h3>Commercial Solar</h3>
                <p>Tailored solar solutions for businesses of all sizes, designed to maximize ROI and minimize operational costs.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaLeaf />
                </div>
                <h3>Off-Grid Systems</h3>
                <p>Complete independence from the electrical grid with battery storage solutions for continuous power supply.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaSun />
                </div>
                <h3>Solar Maintenance</h3>
                <p>Regular maintenance services to ensure optimal system performance and longevity of your solar installation.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaChartLine />
                </div>
                <h3>Energy Analysis</h3>
                <p>Comprehensive energy consumption analysis to design the most efficient solar solution for your specific needs.</p>
              </div>
            </Col>
          </Row>
          
          <Row className="align-items-center">
            <Col lg={6} className="mb-4 mb-lg-0">
              <img 
                src="https://images.unsplash.com/photo-1521618755572-156ae0cdd74d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Solar Installation Team" 
                className="img-fluid rounded shadow"
              />
            </Col>
            <Col lg={6}>
              <h3 className="h2 mb-4">Benefits of Solar Energy for Your Business</h3>
              <FeatureItem>Significant reduction in electricity costs with ROI typically achieved within 3-5 years</FeatureItem>
              <FeatureItem>Enhanced corporate social responsibility through substantial reduction in carbon footprint</FeatureItem>
              <FeatureItem>Protection against rising electricity costs and unpredictable price fluctuations</FeatureItem>
              <FeatureItem>Increased property value and potential tax incentives depending on location</FeatureItem>
              <FeatureItem>Reliable power backup during grid outages when paired with battery storage</FeatureItem>
              <FeatureItem>Minimal maintenance requirements with systems typically warranted for 25+ years</FeatureItem>
              <div className="mt-4">
                <Link to="/contact">
                  <Button variant="primary">Schedule Your Solar Assessment</Button>
                </Link>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
      
      {/* CTA Section */}
      <section className="section bg-light-subtle">
        <Container>
          <Row className="text-center">
            <Col lg={8} className="mx-auto">
              <h2 className="section-title text-center">Ready to Harness Solar Power?</h2>
              <p className="mb-4">Our solar experts are ready to help you transition to sustainable energy. Contact us today for a comprehensive assessment and custom quote.</p>
              <Link to="/contact">
                <Button variant="primary" size="lg">Contact Our Solar Team</Button>
              </Link>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default SolarPage;
