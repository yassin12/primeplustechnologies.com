import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import PageHeader from '../components/PageHeader';
import FeatureItem from '../components/FeatureItem';
import { FaLaptop, FaServer, FaDesktop, FaTabletAlt } from 'react-icons/fa';

const EquipmentPage = () => {
  return (
    <>
      <PageHeader 
        title="ICT Equipment Supply" 
        breadcrumbs={[{ text: "ICT Equipment Supply" }]} 
      />
      
      <section className="section">
        <Container>
          <Row className="align-items-center mb-5">
            <Col lg={6} className="mb-4 mb-lg-0">
              <h2 className="section-title">Quality ICT Equipment Supply</h2>
              <p>As an authorized distributor for leading technology brands, PRIME PLUS TECHNOLOGIES provides genuine hardware with full warranty support to keep your operations running smoothly.</p>
              <p>Our comprehensive equipment supply service ensures you get the right technology for your specific needs at competitive prices, with expert guidance throughout the procurement process.</p>
              <h4 className="h5 mt-4 mb-3">What We Offer:</h4>
              <FeatureItem>Workstations, servers & networking gear</FeatureItem>
              <FeatureItem>Peripherals & accessories</FeatureItem>
              <FeatureItem>Bulk procurement with volume discounts</FeatureItem>
              <FeatureItem>Asset tagging & inventory management</FeatureItem>
              <div className="mt-4">
                <Link to="/contact">
                  <Button variant="primary">Request Equipment Quote</Button>
                </Link>
              </div>
            </Col>
            <Col lg={6}>
              <img 
                src="https://images.unsplash.com/photo-1515343480029-43cdfe6b6aae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="ICT Equipment" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
          
          <Row className="mb-5">
            <Col>
              <h3 className="h2 mb-4">Equipment Categories</h3>
            </Col>
          </Row>
          
          <Row className="mb-5">
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaDesktop />
                </div>
                <h3>Computing Devices</h3>
                <p>Desktop computers, workstations, and all-in-one systems from leading manufacturers like HP, Dell, and Lenovo.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaLaptop />
                </div>
                <h3>Laptops & Mobility</h3>
                <p>Business laptops, ultrabooks, and mobile workstations designed for productivity on the go.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaServer />
                </div>
                <h3>Servers & Storage</h3>
                <p>Enterprise-grade servers, storage arrays, and backup solutions for your critical business data.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaTabletAlt />
                </div>
                <h3>Peripherals & Accessories</h3>
                <p>Monitors, keyboards, mice, docking stations, and other essential peripherals for your workspace.</p>
              </div>
            </Col>
          </Row>
          
          <Row className="align-items-center">
            <Col lg={6} className="order-lg-2 mb-4 mb-lg-0">
              <h3 className="h2 mb-4">Our Equipment Supply Advantage</h3>
              <FeatureItem>Authorized partner for major technology brands ensuring genuine products</FeatureItem>
              <FeatureItem>Expert guidance in selecting the right equipment for your specific requirements</FeatureItem>
              <FeatureItem>Competitive pricing with special discounts for bulk orders</FeatureItem>
              <FeatureItem>Complete warranty support and after-sales service</FeatureItem>
              <FeatureItem>Asset management services including tagging, inventory tracking, and lifecycle management</FeatureItem>
              <FeatureItem>Efficient procurement process with quick delivery timelines</FeatureItem>
              <div className="mt-4">
                <Link to="/contact">
                  <Button variant="primary">Discuss Your Equipment Needs</Button>
                </Link>
              </div>
            </Col>
            <Col lg={6} className="order-lg-1">
              <img 
                src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Office Equipment" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
        </Container>
      </section>
      
      {/* CTA Section */}
      <section className="section bg-light-subtle">
        <Container>
          <Row className="text-center">
            <Col lg={8} className="mx-auto">
              <h2 className="section-title text-center">Looking for Specific Equipment?</h2>
              <p className="mb-4">From individual items to complete office setups, our team is ready to help you source the right equipment at competitive prices.</p>
              <Link to="/contact">
                <Button variant="primary" size="lg">Contact Our Equipment Team</Button>
              </Link>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default EquipmentPage;
