import React from 'react';
import { Container, Row, Col, Breadcrumb } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const PageHeader = ({ title, breadcrumbs }) => {
  return (
    <div className="page-header">
      <Container>
        <Row>
          <Col>
            <h1>{title}</h1>
            <Breadcrumb>
              <Breadcrumb.Item linkAs={Link} linkProps={{ to: "/" }}>Home</Breadcrumb.Item>
              {breadcrumbs.map((breadcrumb, index) => (
                <Breadcrumb.Item 
                  key={index}
                  active={index === breadcrumbs.length - 1}
                  linkAs={index < breadcrumbs.length - 1 ? Link : undefined}
                  linkProps={index < breadcrumbs.length - 1 ? { to: breadcrumb.link } : undefined}
                >
                  {breadcrumb.text}
                </Breadcrumb.Item>
              ))}
            </Breadcrumb>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default PageHeader;
