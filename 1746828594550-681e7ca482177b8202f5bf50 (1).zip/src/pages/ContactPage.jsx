import React from 'react';
import { Container, Row, Col, Form, Button, Card } from 'react-bootstrap';
import PageHeader from '../components/PageHeader';
import { FaPhone, FaEnvelope, FaMapMarkerAlt } from 'react-icons/fa';

const ContactPage = () => {
  return (
    <>
      <PageHeader 
        title="Contact Us" 
        breadcrumbs={[{ text: "Contact Us" }]} 
      />
      
      <section className="section">
        <Container>
          <Row className="mb-5">
            <Col lg={6} className="mb-5 mb-lg-0">
              <h2 className="section-title">Get In Touch</h2>
              <p className="mb-4">Have questions about our services? Ready to start a project? Contact our team for expert assistance.</p>
              
              <Form>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Full Name</Form.Label>
                      <Form.Control type="text" placeholder="Enter your full name" />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Email Address</Form.Label>
                      <Form.Control type="email" placeholder="Enter your email" />
                    </Form.Group>
                  </Col>
                </Row>
                
                <Form.Group className="mb-3">
                  <Form.Label>Phone Number</Form.Label>
                  <Form.Control type="tel" placeholder="Enter your phone number" />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Subject</Form.Label>
                  <Form.Control type="text" placeholder="What is this regarding?" />
                </Form.Group>
                
                <Form.Group className="mb-4">
                  <Form.Label>Message</Form.Label>
                  <Form.Control as="textarea" rows={5} placeholder="How can we help you?" />
                </Form.Group>
                
                <Button variant="primary" type="submit" size="lg">
                  Send Message
                </Button>
              </Form>
            </Col>
            
            <Col lg={6}>
              <Row>
                <Col md={6} className="mb-4">
                  <Card className="contact-card h-100">
                    <div className="contact-icon mx-auto">
                      <FaPhone />
                    </div>
                    <h4>Call Us</h4>
                    <p className="mb-0">+252-617527771</p>
                    <p>+252-610855016</p>
                  </Card>
                </Col>
                
                <Col md={6} className="mb-4">
                  <Card className="contact-card h-100">
                    <div className="contact-icon mx-auto">
                      <FaEnvelope />
                    </div>
                    <h4>Email Us</h4>
                    <p className="mb-0">info@primeplustechnologies.com</p>
                  </Card>
                </Col>
                
                <Col md={12} className="mb-4">
                  <Card className="contact-card h-100">
                    <div className="contact-icon mx-auto">
                      <FaMapMarkerAlt />
                    </div>
                    <h4>Visit Us</h4>
                    <p className="mb-0">Vinta une October Rd,</p>
                    <p>Waaberi District, Mogadishu, Somalia</p>
                  </Card>
                </Col>
              </Row>
              
              <div className="mt-4 rounded overflow-hidden shadow">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d254440.21005788324!2d45.14158864335938!3d2.046175500000005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3d58425956d7f2b9%3A0x5e0da1558e581b91!2sMogadishu%2C%20Somalia!5e0!3m2!1sen!2sus!4v1699539136402!5m2!1sen!2sus" 
                  width="100%" 
                  height="300" 
                  style={{ border: 0 }} 
                  allowFullScreen="" 
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Prime Plus Technologies Location"
                ></iframe>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
      
      {/* Office Hours Section */}
      <section className="section bg-light-subtle">
        <Container>
          <Row className="text-center">
            <Col lg={8} className="mx-auto">
              <h2 className="section-title text-center">Business Hours</h2>
              <p className="mb-4">Our team is available to assist you during the following hours:</p>
              <div className="d-flex justify-content-between mb-2">
                <span className="fw-bold">Monday - Friday:</span>
                <span>8:00 AM - 6:00 PM</span>
              </div>
              <div className="d-flex justify-content-between mb-2">
                <span className="fw-bold">Saturday:</span>
                <span>9:00 AM - 2:00 PM</span>
              </div>
              <div className="d-flex justify-content-between">
                <span className="fw-bold">Sunday:</span>
                <span>Closed</span>
              </div>
              <p className="mt-4">For emergencies outside business hours, please call our support line.</p>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default ContactPage;
