import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import PageHeader from '../components/PageHeader';
import FeatureItem from '../components/FeatureItem';
import { FaVideo, FaFingerprint, FaMobileAlt, FaShieldAlt } from 'react-icons/fa';

const CCTVPage = () => {
  return (
    <>
      <PageHeader 
        title="CCTV & Access Controls" 
        breadcrumbs={[{ text: "CCTV & Access Controls" }]} 
      />
      
      <section className="section">
        <Container>
          <Row className="align-items-center mb-5">
            <Col lg={6} className="mb-4 mb-lg-0">
              <h2 className="section-title">Intelligent Security Systems</h2>
              <p>Our intelligent security systems provide 360° protection with smart surveillance and restricted access management tailored to your facility's needs. We design, install, and maintain comprehensive security solutions that protect your people, property, and assets.</p>
              <p>With advanced CCTV and access control technologies, we help businesses create secure environments while maintaining operational efficiency.</p>
              <h4 className="h5 mt-4 mb-3">What We Offer:</h4>
              <FeatureItem>HD/IP camera installation (indoor/outdoor)</FeatureItem>
              <FeatureItem>Night vision & motion detection systems</FeatureItem>
              <FeatureItem>Biometric & card-based access control</FeatureItem>
              <FeatureItem>Remote monitoring & mobile alerts</FeatureItem>
              <FeatureItem>Security system integration (CCTV + access)</FeatureItem>
              <div className="mt-4">
                <Link to="/contact">
                  <Button variant="primary">Request Security Consultation</Button>
                </Link>
              </div>
            </Col>
            <Col lg={6}>
              <img 
                src="https://images.unsplash.com/photo-1610641818989-c2051b5e2cfd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Security Camera Systems" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
          
          <Row className="mb-5">
            <Col>
              <h3 className="h2 mb-4">Our Security Solutions</h3>
            </Col>
          </Row>
          
          <Row className="mb-5">
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaVideo />
                </div>
                <h3>CCTV Systems</h3>
                <p>High-definition surveillance cameras with advanced features such as night vision, motion detection, and remote viewing capabilities.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaFingerprint />
                </div>
                <h3>Access Control</h3>
                <p>Secure entry systems using cards, biometrics, or PIN codes to restrict and monitor access to sensitive areas.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaMobileAlt />
                </div>
                <h3>Remote Monitoring</h3>
                <p>24/7 remote access to your security systems via mobile apps for real-time surveillance and alerts.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaShieldAlt />
                </div>
                <h3>Integrated Security</h3>
                <p>Comprehensive security solutions that integrate multiple systems for centralized management and enhanced protection.</p>
              </div>
            </Col>
          </Row>
          
          <Row className="align-items-center">
            <Col lg={6} className="mb-4 mb-lg-0">
              <img 
                src="https://images.unsplash.com/photo-1541976498248-c3c4f5c1f9c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Access Control Systems" 
                className="img-fluid rounded shadow"
              />
            </Col>
            <Col lg={6}>
              <h3 className="h2 mb-4">Benefits of Professional Security Systems</h3>
              <FeatureItem>Deterrence of theft, vandalism, and unauthorized access</FeatureItem>
              <FeatureItem>Real-time monitoring and instant alerts for security breaches</FeatureItem>
              <FeatureItem>Detailed access logs and video evidence for investigations</FeatureItem>
              <FeatureItem>Remote management of multiple sites from a single interface</FeatureItem>
              <FeatureItem>Enhanced employee safety and compliance with security regulations</FeatureItem>
              <FeatureItem>Integration with other building systems for comprehensive protection</FeatureItem>
              <div className="mt-4">
                <Link to="/contact">
                  <Button variant="primary">Schedule a Security Assessment</Button>
                </Link>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
      
      {/* CTA Section */}
      <section className="section bg-light-subtle">
        <Container>
          <Row className="text-center">
            <Col lg={8} className="mx-auto">
              <h2 className="section-title text-center">Ready to Enhance Your Security?</h2>
              <p className="mb-4">Our security experts will assess your facility and recommend the ideal CCTV and access control solutions for your specific needs.</p>
              <Link to="/contact">
                <Button variant="primary" size="lg">Contact Our Security Team</Button>
              </Link>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default CCTVPage;
