import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import SolarPage from './pages/SolarPage';
import ICTSolutionsPage from './pages/ICTSolutionsPage';
import EquipmentPage from './pages/EquipmentPage';
import PrinterPage from './pages/PrinterPage';
import CCTVPage from './pages/CCTVPage';
import ContactPage from './pages/ContactPage';

function App() {
  return (
    <>
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/solar" element={<SolarPage />} />
          <Route path="/ict-solutions" element={<ICTSolutionsPage />} />
          <Route path="/equipment" element={<EquipmentPage />} />
          <Route path="/printer-services" element={<PrinterPage />} />
          <Route path="/cctv" element={<CCTVPage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
      </main>
      <Footer />
    </>
  );
}

export default App;
