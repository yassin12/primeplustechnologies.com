import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import PageHeader from '../components/PageHeader';
import FeatureItem from '../components/FeatureItem';
import { FaPrint, FaCog, FaTools, FaChartLine } from 'react-icons/fa';

const PrinterPage = () => {
  return (
    <>
      <PageHeader 
        title="Printer Maintenance & Installation" 
        breadcrumbs={[{ text: "Printer Services" }]} 
      />
      
      <section className="section">
        <Container>
          <Row className="align-items-center mb-5">
            <Col lg={6} className="mb-4 mb-lg-0">
              <h2 className="section-title">Professional Printer Solutions</h2>
              <p>We optimize your document workflow with professional printer solutions for businesses of all sizes. From high-volume office environments to specialized printing needs, our certified technicians ensure your equipment operates at peak performance.</p>
              <p>Our comprehensive printer services include installation, maintenance, supply management, and optimization to maximize efficiency and minimize downtime.</p>
              <h4 className="h5 mt-4 mb-3">What We Offer:</h4>
              <FeatureItem>Installation & configuration of heavy-duty printers (HP, Canon, Xerox)</FeatureItem>
              <FeatureItem>Routine maintenance & emergency repairs</FeatureItem>
              <FeatureItem>Genuine toner/ink cartridges & replacement parts</FeatureItem>
              <FeatureItem>Print management solutions & cost optimization</FeatureItem>
              <FeatureItem>Staff training on operation & basic troubleshooting</FeatureItem>
              <div className="mt-4">
                <Link to="/contact">
                  <Button variant="primary">Request Printer Service</Button>
                </Link>
              </div>
            </Col>
            <Col lg={6}>
              <img 
                src="https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Printer Services" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
          
          <Row className="mb-5">
            <Col>
              <h3 className="h2 mb-4">Our Printer Service Capabilities</h3>
            </Col>
          </Row>
          
          <Row className="mb-5">
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaPrint />
                </div>
                <h3>Printer Installation</h3>
                <p>Professional setup and configuration of printers, multifunction devices, and printing networks for optimal performance.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaTools />
                </div>
                <h3>Maintenance & Repair</h3>
                <p>Scheduled preventative maintenance and emergency repair services to minimize downtime and extend equipment life.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaCog />
                </div>
                <h3>Supplies Management</h3>
                <p>Genuine consumables delivery and inventory management services to ensure you never run out of toner or ink.</p>
              </div>
            </Col>
            
            <Col lg={3} md={6} className="mb-4">
              <div className="feature-box text-center h-100">
                <div className="feature-icon">
                  <FaChartLine />
                </div>
                <h3>Print Management</h3>
                <p>Advanced print management solutions to track usage, reduce waste, and optimize printing costs across your organization.</p>
              </div>
            </Col>
          </Row>
          
          <Row className="align-items-center">
            <Col lg={6} className="order-lg-2 mb-4 mb-lg-0">
              <h3 className="h2 mb-4">Benefits of Our Printer Services</h3>
              <FeatureItem>Reduced downtime with preventative maintenance and priority support</FeatureItem>
              <FeatureItem>Cost savings through improved efficiency and reduced waste</FeatureItem>
              <FeatureItem>Extended equipment lifespan through proper maintenance</FeatureItem>
              <FeatureItem>Consistent print quality for professional business documents</FeatureItem>
              <FeatureItem>Simplified budgeting with service contracts and supplies management</FeatureItem>
              <FeatureItem>Expert setup for optimal network integration and security</FeatureItem>
              <div className="mt-4">
                <Link to="/contact">
                  <Button variant="primary">Schedule a Service Appointment</Button>
                </Link>
              </div>
            </Col>
            <Col lg={6} className="order-lg-1">
              <img 
                src="https://images.unsplash.com/photo-1589561253898-768105ca91a8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="Printer Maintenance" 
                className="img-fluid rounded shadow"
              />
            </Col>
          </Row>
        </Container>
      </section>
      
      {/* CTA Section */}
      <section className="section bg-light-subtle">
        <Container>
          <Row className="text-center">
            <Col lg={8} className="mx-auto">
              <h2 className="section-title text-center">Need Printer Support?</h2>
              <p className="mb-4">Whether you need a new printer setup or maintenance for your existing fleet, our certified technicians are ready to help.</p>
              <Link to="/contact">
                <Button variant="primary" size="lg">Contact Our Printer Services Team</Button>
              </Link>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default PrinterPage;
